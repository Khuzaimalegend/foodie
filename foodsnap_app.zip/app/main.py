# main.py
from kivy.utils import platform
from kivymd.app import MDApp
import os
from app.screens import FoodSnapApp

if __name__ == "__main__":
    FoodSnapApp().run()
