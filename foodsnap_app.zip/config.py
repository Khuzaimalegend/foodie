# config.py
# Store your API keys and configuration here

# Nutritionix API credentials
NUTRITIONIX_APP_ID = "YOUR_NUTRITIONIX_APP_ID"
NUTRITIONIX_APP_KEY = "YOUR_NUTRITIONIX_APP_KEY"

# Edamam API credentials
EDAMAM_APP_ID = "YOUR_EDAMAM_APP_ID"
EDAMAM_APP_KEY = "YOUR_EDAMAM_APP_KEY"
